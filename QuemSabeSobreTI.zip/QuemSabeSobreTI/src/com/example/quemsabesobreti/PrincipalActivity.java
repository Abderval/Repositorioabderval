package com.example.quemsabesobreti;



import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.view.View.OnClickListener;

public class PrincipalActivity extends Activity {
    //declaracao das variaves para fazer referecina aos bot�es da activity_principal.xml
	View BtnNovo, BtnSair, BtnAcerca, BtnDefinicoes;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_principal);
		
		BtnNovo = findViewById(R.id.BtnNovo);
		BtnAcerca = findViewById(R.id.BtnAcerca);
		BtnSair = findViewById(R.id.BtnSair);
		BtnDefinicoes = findViewById(R.id.BtnDefinicoes);
		
		//botao sair do jogo:
		BtnSair.setOnClickListener(new OnClickListener() {
			
			public void onClick(View v) {
				finish();
				
			}
		});
		/* Button Novo Jogo */
	    BtnNovo.setOnClickListener(new OnClickListener() {
		
		public void onClick(View v) {
			// codigo para chamar outra activity ou formulario (JogarActivity)
			
		}
	});

		
	}

	

}
