/**
 * 
 */

/**
 * Date:08/02/2016
 * @author Rosario
 * 
 */
public class MatematicaNumerica {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("Hecho con ---> Biseccion");
		Biseccion bisecion = new Biseccion();
		float res = bisecion.biseccion(1, 2, (float) 0.0001);
		System.out.println("Raiz: "+res);
		////////////////////regula falsi
		System.out.println("Hecho con ---> Regula-Falsi");
		Regula_Falsi_Rosario regula=new Regula_Falsi_Rosario();
		float result=regula.FalsePosicion(1, 2, (float) 0.0001);
		System.out.println("Raiz: "+result);
		////////////////newton raphson
		System.out.println("Hecho con ---> Newton-Raphson");
		NewtonRaphsonRosario newton=new NewtonRaphsonRosario();
		float resNR=newton.NewtonR(2,0.0001);
		System.out.println("Raiz"+resNR);
		
	}

}
