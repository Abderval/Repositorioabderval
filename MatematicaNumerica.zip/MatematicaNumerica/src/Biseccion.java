

/**
 * 
 */

/**
 * @author Rosario metodo de Biseccion. data:08/2/2016 Hora:1:52
 */
public class Biseccion {


	private int iteraciones = 0;
	public Biseccion() {
	};

	public float funcion(float X) {
		
		return (X*X) + (X)+ -4;

	}

	public float biseccion(float a, float b, float error) {
		
		float x = (a + b) / 2;
		float e = (b - a) / 2;

		while (e >= error) {
			if (funcion(x) == 0) {
				e = 0;
			} else {
				if (funcion(x) * funcion(a) >= 0) {
					a = x;
				} else {
					b = x;
				}

				x = (a + b) / 2;
				e = Math.abs(b - a) / 2;
				setIteraciones(getIteraciones() + 1);
			}

		}
		System.out.println("Cant Iteraciones: " + getIteraciones());
		return x;
	}

	public int getIteraciones() {
		return iteraciones;
	}

	public void setIteraciones(int iteraciones) {
		this.iteraciones = iteraciones;
	}

	


	

}
