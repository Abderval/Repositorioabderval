
/*Autor:Rosario
 * data:08/2/2016
 * Hora:1:52*/
public class NewtonRaphsonRosario {

	public NewtonRaphsonRosario() {

	}

	public double funcioInterar(double x)// Funcion sin Derivar
	{
		return (x * x) + (x) + -4;
	}

	public double funcioDerivada(double x)// poner aqui la derivada de la
											// funcion
	{
		return (2 * x) + 1;
	}

	public float NewtonR(float x, double e) // Metodo para resolver la funcion
	{
		double n = 0;
		double xAnt = x;
		double error = 0.01;
		int iteraciones = 0;

		while (error > e) {
			x = (float) (xAnt - ((funcioInterar(xAnt)) / funcioDerivada(xAnt)));
			error = Math.abs(x - xAnt);
			xAnt = x;
			n = n + 1;
			iteraciones++;
		}
		System.out.println("Cant Iteraciones: " + iteraciones);
		return x;
	}

}
