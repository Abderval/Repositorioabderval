
/**
 * @author Rosario Segundo ANO DE Informatica Autor:Rosario data:08/2/2016
 *         Hora:1:52
 * */
public class Regula_Falsi_Rosario {

	public Regula_Falsi_Rosario() {
	}

	
	private int iteraciones = 0;
	
	public float funcion(float X) {
		return (X * X) + (X) -4;

	}

	public float FalsePosicion(float a, float b, float e) {
		float x = 0;
		float n = 0;
		float xAnt = a;
		float error = 0.01f;
		// x = (a * funcion(b) - funcion(a)) / funcion(b) - funcion(a);
		float ya = funcion(a);
		float yb = funcion(b);
		float yx;
		
		
		while (error > e) {
			n = n + 1;
			x =  ((a) - ((b - a) / (yb - ya)) * ya);
			error = Math.abs(xAnt - x);
			yx = funcion(x);
			if (ya * funcion(x) < 0) {
				b = x;
				yb = yx;
			} else {
				a = x;
				ya = yx;
			}
			xAnt = x;
			iteraciones++;
		}
		System.out.println("Iteraciones con RF " + iteraciones);
		return x;

	}

	
	
}
