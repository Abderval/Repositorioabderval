package com.example.matematicanumericaapk;
/**
 * @author Rosario Segundo ANO DE Informatica Autor:Rosario data:08/2/2016
 *         Hora:1:52
 * */
public class Regula_Falsi_Rosario {

	public Regula_Falsi_Rosario() {
	}

	private Double ec1;
	private Double ec2;
	private Double ec3;
	private int iteraciones = 0;
	
	public Double funcion(Double X) {
		return (ec1*X * X) + (ec2*X) + ec3;

	}

	public Double FalsePosicion(Double a, Double b, Double e) {
		double x = 0;
		double n = 0;
		double xAnt = a;
		double error = 0.01d;
		// x = (a * funcion(b) - funcion(a)) / funcion(b) - funcion(a);
		double ya = funcion(a);
		double yb = funcion(b);
		double yx;
		
		
		while (error > e) {
			n = n + 1;
			x =  ((a) - ((b - a) / (yb - ya)) * ya);
			error = Math.abs(xAnt - x);
			yx = funcion(x);
			if (ya * funcion(x) < 0) {
				b = x;
				yb = yx;
			} else {
				a = x;
				ya = yx;
			}
			xAnt = x;
			setIteraciones(getIteraciones() + 1);
		}
		System.out.println("Iteraciones con RF " + getIteraciones());
		return x;

	}

	public void setEc1(Double ec1) {
		this.ec1 = ec1;
	}

	
	public void setEc2(Double ec2) {
		this.ec2 = ec2;
	}

	

	public void setEc3(Double ec3) {
		this.ec3 = ec3;
	}

	public int getIteraciones() {
		return iteraciones;
	}

	public void setIteraciones(int iteraciones) {
		this.iteraciones = iteraciones;
	}
}
