package com.example.matematicanumericaapk;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity {

	EditText edEc1, edEc2, edEc3, tvA, tvB, tvError, edReg1, edReg2, edReg3;
	TextView lblRes, cant;
	Double a;
	Double b;
	Double error;
	Double val1, val2, val3, valr1, valr2, valr3;

	Biseccion biseccion = new Biseccion();
	Regula_Falsi_Rosario regulaf = new Regula_Falsi_Rosario();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		Button BtnCalcular = (Button) findViewById(R.id.BtnBiseccion);
		Button BtnRegula = (Button) findViewById(R.id.BtnRegulaF);
		// Button BtnNewton = (Button) findViewById(R.id.BtnRegulaF);

		edEc1 = (EditText) findViewById(R.id.edEc1);
		edEc2 = (EditText) findViewById(R.id.edEcu2);
		edEc3 = (EditText) findViewById(R.id.edecIndependente);
		edReg1 = (EditText) findViewById(R.id.edReg1);
		edReg2 = (EditText) findViewById(R.id.edReg2);
		edReg3 = (EditText) findViewById(R.id.edReg3);

		tvA = (EditText) findViewById(R.id.edA);
		tvB = (EditText) findViewById(R.id.edB);
		tvError = (EditText) findViewById(R.id.edError);
		lblRes = (TextView) findViewById(R.id.LblResult);
		cant = (TextView) findViewById(R.id.txtCantIteraciones);

		BtnCalcular.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Biseccion2();

				Double res = biseccion.biseccion(a, b, error);
				lblRes.setText("resultado con Bisecc: " + res.toString());
				int a = biseccion.getIteraciones();
				cant.setText(String.valueOf(a));
			}
		});
		BtnRegula.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Rf();
				Double res = regulaf.FalsePosicion(a, b, error);
				lblRes.setText("resultado con RF: " + res.toString());
				int a = regulaf.getIteraciones();
				cant.setText(String.valueOf(a));
			}
		});

	}

	public void Biseccion2() {
		a = Double.parseDouble(tvA.getText().toString());
		b = Double.parseDouble(tvB.getText().toString());
		error = Double.parseDouble(tvError.getText().toString());

		val1 = Double.parseDouble(edEc1.getText().toString());
		val2 = Double.parseDouble(edEc2.getText().toString());
		val3 = Double.parseDouble(edEc3.getText().toString());

		biseccion.setEc1(val1);
		biseccion.setEc2(val2);
		biseccion.setEc3(val3);

	}

	public void Rf() {
		a = Double.parseDouble(tvA.getText().toString());
		b = Double.parseDouble(tvB.getText().toString());
		error = Double.parseDouble(tvError.getText().toString());

		valr1 = Double.parseDouble(edReg1.getText().toString());
		valr2 = Double.parseDouble(edReg2.getText().toString());
		valr3 = Double.parseDouble(edReg3.getText().toString());

		regulaf.setEc1(valr1);
		regulaf.setEc2(valr2);
		regulaf.setEc3(valr3);

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
