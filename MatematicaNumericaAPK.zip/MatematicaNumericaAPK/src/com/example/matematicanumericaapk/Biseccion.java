package com.example.matematicanumericaapk;

/**
 * 
 */

/**
 * @author Rosario metodo de Biseccion. data:08/2/2016 Hora:1:52
 */
public class Biseccion {

	private Double ec1;
	private Double ec2;
	private Double ec3;
	private int iteraciones = 0;
	public Biseccion() {
	};

	public Double funcion(Double X) {
		
		return (ec1*X * X) + (ec2*X) + ec3;

	}

	public Double biseccion(Double a, Double b, Double error) {
		
		Double x = (a + b) / 2;
		Double e = (b - a) / 2;

		while (e >= error) {
			if (funcion(x) == 0) {
				e = 0d;
			} else {
				if (funcion(x) * funcion(a) >= 0) {
					a = x;
				} else {
					b = x;
				}

				x = (a + b) / 2;
				e = Math.abs(b - a) / 2;
				iteraciones++;
			}

		}
		System.out.println("Cant Iteraciones: " + getIteraciones());
		return x;
	}

	

	public void setEc1(Double ec1) {
		this.ec1 = ec1;
	}

	
	public void setEc2(Double ec2) {
		this.ec2 = ec2;
	}

	

	public void setEc3(Double ec3) {
		this.ec3 = ec3;
	}

	public int getIteraciones() {
		return iteraciones;
	}

	public void setIteraciones(int iteraciones) {
		this.iteraciones = iteraciones;
	}
}
